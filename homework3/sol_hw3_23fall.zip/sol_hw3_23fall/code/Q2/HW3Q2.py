# !/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: PC
"""
import pandas as pd 
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from scipy.stats import gaussian_kde as gkde


# read data
data = pd.read_csv("n90pol.csv")


bw = 0.3

# get the range of data
range_amygdala = [min(data['amygdala']), max(data['amygdala'])]
range_acc = [min(data['acc']), max(data['acc'])]
range_orientation = [min(data['orientation']), max(data['orientation'])]

# get all choices of orientation and separate data
ranges = list(set(data['orientation']))
dataset = []
for i in range(len(ranges)):
    dataset.append(data[data['orientation'] == ranges[i]])

##### (a) #########
# # plot 1d histogram
fig1, ax1 = plt.subplots(2,2)

sns.histplot(data, x='amygdala',  bins=20, ax=ax1.flat[0])
ax1[0,0].title.set_text('histogram: amy')

sns.histplot(data, x='acc',  bins=20, ax=ax1.flat[1])
ax1[0,1].title.set_text('histogram: acc')

sns.kdeplot(data= data, x="amygdala",   ax=ax1.flat[2], bw_method=bw)
ax1[1,0].title.set_text('kde: amy')

sns.kdeplot(data= data, x="acc",   ax=ax1.flat[3], bw_method=bw)
ax1[1,1].title.set_text('kde: acc')

fig1.tight_layout(pad=1.0)
fig1.suptitle('1-D plots')
plt.show()


##### (b) #########
# # plot 2d histogram
fig2, ax2 = plt.subplots(1,2, sharey=True)
sns.histplot(data, x='amygdala', y='acc', bins=20, ax=ax2.flat[0])
ax2[0].title.set_text('2-D histogram')

sns.kdeplot(data= data, x="amygdala", y='acc',  ax=ax2.flat[1])
ax2[1].title.set_text('2-D KDE')

fig1.tight_layout(pad=2.0)
fig1.suptitle('2-D plots')
#plt.savefig('2d-kde.pdf')
plt.show()


##### (c) #########
# ##f(x).f(y)

# # create the coordinates ranges for the 2D plot
xx = np.linspace(-0.15, 0.15, 31)
yy = np.linspace(-0.15, 0.15, 31)

h1 = 0.1 # set the bandwidth
fx = gkde(data.loc[:, ['amygdala']].values.T, bw_method= bw) # # fit kde function with given data
fx_val = fx.evaluate(xx)  # # evaluate the designed data with above kde function

fy = gkde(data.loc[:, ['acc']].values.T,bw_method= bw)
fy_val = fy.evaluate(yy)


fxfy_val = np.outer(fx_val, fy_val.T)

# ## f(x,y)
fxy = gkde(data.loc[:, ['amygdala','acc']].values.T,bw_method=bw)

# # use meshgrid for all 2-D plot locations
xgrid, ygrid = np.meshgrid(xx, yy)
# # flat the meshgrid into 2d location pairs
grid_coords = np.append(xgrid.reshape(-1, 1), ygrid.reshape(-1,1), axis = 1)

z = fxy.evaluate(grid_coords.T)
fxy_val = z.reshape(xgrid.shape).T # need to transpose due to python reshape mechanism, otherwise the dimension not consistent

errmap = np.abs(fxy_val - fxfy_val)

ext = [xx[0], xx[-1], yy[0], yy[-1]]

fig3, ax3 = plt.subplots(1,3)
ax3[0].imshow(fxfy_val, extent=ext)
ax3[0].title.set_text('f(x)f(y)')

ax3[1].imshow(fxy_val, extent=ext)
ax3[1].title.set_text('f(x,y)')

ax3[2].imshow(errmap, extent=ext)
ax3[2].title.set_text('|f(x)f(y)-f(x,y)|')

fig3.suptitle('ignore orientation')
fig3.tight_layout()
plt.show()

#%%
##### (d) #########
# consider the orientation
# # utilizing pandas DataFrame can simplify the orientation selection
grouped = data.groupby('orientation')
orientation_mesh = np.unique(data.orientation)

fig4, ax4 = plt.subplots(2, 4, sharex=True, sharey=True, figsize=(8,4))

bw1 = 0.5

for ii in range(4):
    
    ori = orientation_mesh[ii]
    sns.kdeplot(data= grouped.get_group(ori), x="amygdala",  ax=ax4[0,ii], bw_method=bw1)
    ax4[0,ii].title.set_text('amy, C='+str(ori))
    
    sns.kdeplot(data= grouped.get_group(ori), x="acc",       ax=ax4[1,ii], bw_method=bw1)
    ax4[1,ii].title.set_text('acc, C='+str(ori))
fig4.suptitle('1D kde for each orientation C')
# plt.savefig('condiProb.pdf')
plt.show()

# display sample mean
for ii in range(4):
    ori = orientation_mesh[ii]
    mu1 = grouped.get_group(ori)['amygdala'].values.mean()
    mu2 = grouped.get_group(ori)['acc'].values.mean()
    print('\n orientation:', str(ori))
    print('sample mean for amygdala:', str(round(mu1,4)))
    print('sample mean for acc:', str(round(mu2,4)))

#%%
##### (e) #########

fig5, ax5 = plt.subplots(2, 2, sharex=True, sharey=True, figsize=(10,12))
ax5 = ax5.ravel()
for ii in range(4):
    ori = orientation_mesh[ii]

    fxy = gkde(grouped.get_group(ori).loc[:, ['amygdala','acc']].values.T,bw_method=bw)
    xgrid, ygrid = np.meshgrid(xx, yy)
    grid_coords = np.append(xgrid.reshape(-1, 1), ygrid.reshape(-1,1), axis = 1)
    
    z = fxy.evaluate(grid_coords.T)
    fxy_val = z.reshape(xgrid.shape).T

    
    ax5[ii].imshow(fxy_val)
    ax5[ii].title.set_text('f(x,y|c), C='+str(ori))
plt.show()

