#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from pathlib import Path
import scipy.io
import csv
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

np.random.seed(2) # changing the random seed may lead to different results

raw = []
file2open = 'marriage.csv'
with open(file2open) as cf:
    readcsv = csv.reader(cf, delimiter=',')
    for row in readcsv:
        raw.append(row)        
        data = np.array(raw).astype('float')
        
x = data[:, 0:-1]
y = data[:, -1]


del raw, data, file2open, cf


def threeClassifier(target_x, target_y, noise_level, ntrials):
    
    rate_nb, rate_lr, rate_kn = np.zeros(ntrials),np.zeros(ntrials),np.zeros(ntrials)
    for ii in range(ntrials):
        
        X_train, X_test, y_train, y_test = train_test_split(target_x, target_y, test_size=0.2)
        ntest = len(y_test)
        
        # Naive Bayes
        nb = GaussianNB(var_smoothing = noise_level)
        y_pred_nb = nb.fit(X_train, y_train).predict(X_test)
        rate_nb[ii] = sum(y_pred_nb==y_test)/ntest
        
        # Logistic regression
        lr = LogisticRegression(random_state=0).fit(X_train, y_train)
        y_pred_lr = lr.predict(X_test)
        rate_lr[ii] = sum(y_pred_lr==y_test)/ntest
        
        # knn
        kn = KNeighborsClassifier(n_neighbors=5).fit(X_train, y_train)
        y_pred_kn = kn.predict(X_test)
        rate_kn[ii] = sum(y_pred_kn==y_test)/ntest
    
    acc_nb = rate_nb.mean()
    acc_lr = rate_lr.mean()
    acc_kn = rate_kn.mean()    
    return acc_nb, acc_lr, acc_kn


# define a function to plot decision boundary
# Reference
# https://stackoverflow.com/questions/45075638/graph-k-nn-decision-boundaries-in-matplotlib
def plot_decision_boundary(model, title, x_train, x_test, y_train):
        
    h = 0.01
    cmap_light = ListedColormap(['#FFAAAA',  '#AAAAFF'])
    cmap_bold = ListedColormap(['#FF0000',  '#0000FF'])

    x_min, x_max = x_train[:,0].min(), x_train[:,0].max() 
    y_min, y_max = x_train[:,1].min(), x_train[:,1].max()

    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into a color plot
    Z = Z.reshape(xx.shape)
    plt.figure()
    plt.pcolormesh(xx, yy, Z, cmap=cmap_light, shading='auto')

    # Also plot the training points
    plt.scatter(x_train[:,0], x_train[:,1], c=y_train, cmap=cmap_bold)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.title(title)
    # plt.savefig(title+'.pdf')


def pca2(x_):
    xc = (x_ - x_.mean(axis=0))
    u, s, _ = np.linalg.svd(xc.T @ xc /len(xc))
    xt = xc@u[:,0:2]@np.diag(s[0:2]**-1/2)
    return xt, u, s

# ############ part 1 a
# #~~~~~~~~~~~~~~~   accuracy for marriage
mrg_nb, mrg_lc, mrg_kn = threeClassifier(x, y, 1e-9, 1)
print('result for marriage data')
print('test accuracy of NB: ', mrg_nb)
print('test accuracy of LR: ', mrg_lc)
print('test accuracy of KN: ', mrg_kn)


# ############ part 1 b
# #~~~~~~~~~ boundary plots for marriage data
X_tr, X_te, y_train, y_test = train_test_split(x, y, test_size=0.2)


# perform PCA
X_train, u, s = pca2(X_tr)
X_test = (X_te-X_tr.mean(axis=0))@ u[:, 0:2] @np.diag(s[0:2]**-1/2)

nb = GaussianNB().fit(X_train, y_train)
plot_decision_boundary(nb, 'marriage: Naive Bayes', X_train, X_test, y_train)

lr = LogisticRegression(random_state=0).fit(X_train, y_train)
plot_decision_boundary(lr, 'marriage: Logistic Regression',X_train, X_test, y_train)

kn = KNeighborsClassifier(n_neighbors=3).fit(X_train, y_train)
plot_decision_boundary(kn, 'marriage: KNN', X_train, X_test, y_train)





