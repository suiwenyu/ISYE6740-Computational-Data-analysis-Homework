#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: PFC
"""

import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt

raw=[]
with open('spambase.data') as cf:
    readcsv = csv.reader(cf, delimiter=',')
    for row in readcsv:
        raw.append(row)       
data = np.array(raw).astype('float')

x = data[:, :-1]
y = data[:, -1]


score_forest_test = []
score_forest_oob = []

alpha_range = np.arange(0,2,0.2)
# alpha_range = [0.]

for alpha in alpha_range: 
    xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2)
        
    cforest = RandomForestClassifier(max_depth=None, 
                                     ccp_alpha = alpha, 
                                     oob_score=True
                                     ).fit(xtrain, ytrain)
    ypre_forest = cforest.predict(xtest)
    acc = (ytest==ypre_forest).mean()
    score_forest_test.append(acc)
    score_forest_oob.append(cforest.oob_score_)

err_test = 1-np.array(score_forest_test)
err_oob = 1-np.array(score_forest_oob)
    
plt.figure()
plt.plot(alpha_range, err_test, label='test error')
plt.plot(alpha_range, err_oob, label='OOB error')
plt.title("error rate vs number of trees")
plt.xlabel("alpha")
plt.ylabel("error rate")
# plt.ylim([0.8,1.1])
plt.legend()
# plt.savefig('oob.pdf')
plt.show()



