#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: PFC
"""

import numpy as np
import csv
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt

raw=[]
with open('spambase.data') as cf:
    readcsv = csv.reader(cf, delimiter=',')
    for row in readcsv:
        raw.append(row)       
data = np.array(raw).astype('float')

x = data[:, :-1]
y = data[:, -1]

# plot the tree##
ctree = tree.DecisionTreeClassifier().fit(x, y)
plt.figure() 
tree.plot_tree(ctree, max_depth=3, filled=True)
# plt.savefig('ctree.pdf')
plt.show()

score_forest = []

# training both tree and forest with different number of trees
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2)
for ntree in range(1,60): 

    
    cforest = RandomForestClassifier(n_estimators=ntree, max_depth=20).fit(xtrain, ytrain)
    ypre_forest = cforest.predict(xtest)
    acc = ((ytest==ypre_forest).sum()).astype('float')/len(ytest)
    score_forest.append(acc)

ctree2 = tree.DecisionTreeClassifier(max_depth=20).fit(xtrain, ytrain)
ypre_tree = ctree2.predict(xtest)
acc2 = ((ytest==ypre_tree).sum()).astype('float')/len(ytest)
    
plt.figure()
plt.plot(score_forest, label='Random Forest')
plt.plot([1, 60],[acc2,acc2], label='decision tree')
plt.title("test accuracy vs number of trees")
plt.xlabel("number of trees")
plt.ylabel("test arrucary")
plt.xlim([1,60])
plt.legend()
# plt.savefig('forest.pdf')
plt.show()


print('accuracy for decision tree: {:.3}'.format(acc2))
print('accuracy for decision random forest: {:.3}'.format(max(score_forest)))
