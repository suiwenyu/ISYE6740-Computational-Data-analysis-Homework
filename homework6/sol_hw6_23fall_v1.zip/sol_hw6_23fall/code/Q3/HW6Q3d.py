#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: PFC
"""

import numpy as np
from sklearn.svm import OneClassSVM
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


with open("spambase.data", "r") as f:
    data = np.array([ [ float(d) for d in line.strip("\n").split(",") ] for line in f.readlines() ])

label = data[:, 57]
label = label*-2 +1

xtrain, xtest, ytrain, ytest = train_test_split(data[:, 0:57],label, test_size = 0.2)

idx_normal = np.array(np.where(ytrain==1)).reshape(-1)
xtrain_normal = xtrain[idx_normal, :]

mdl = OneClassSVM(gamma='auto').fit(xtrain_normal)

ypred = mdl.predict(xtest)
matched = ypred==ytest
acc = matched.sum()/len(matched)

print('the test error: {:.2%}'.format(1-acc))