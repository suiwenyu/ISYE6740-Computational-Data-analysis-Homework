#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
this script is for 6740-2021Spring-hw6Q4

@author: PFC
"""
import numpy as np
import matplotlib.pyplot as plt

X = np.array([[1,.5],[1,1.1]])
beta0 = np.array([-1,1])
W = np.diag([1./.5,1./.5])

#part e
# x = np.array([1.,1.])

#part f
x = np.array([1.,1.5])

def my_MSE(lambda_iter,X, beta0, W, x):
    # lambda_iter = 2.
    p = X.shape[0]
    Px = np.linalg.inv(X.T @ W @ X + lambda_iter*np.eye(p)) @  x
    Px = W @ (X @ Px)
    
    bias2 = np.linalg.inv(X.T @ W @ X + lambda_iter*np.eye(p)) @ x
    bias2 = (lambda_iter * beta0.T @ bias2)**2
    
    var = Px.T @ np.linalg.inv(W) @ Px
    
    MSE = bias2 + var
    
    return bias2, var, MSE

lambda_choice = np.linspace(0, 2, 101)
N = lambda_choice.size
bias_batch = np.zeros(N)
var_batch = np.zeros(N)
mse_batch = np.zeros(N)

for ii in range(N):
    bias_batch[ii], var_batch[ii], mse_batch[ii] = my_MSE(lambda_choice[ii], X, beta0, W, x)

plt.plot(lambda_choice,np.log(mse_batch),'r-',label='MSE')
plt.plot(lambda_choice,np.log(var_batch),'k--',label='Variance')
plt.plot(lambda_choice,np.log(bias_batch),'b-.',label='squared bias')
plt.title('Bias Variance Tradeoff')
plt.xlabel('$\lambda$')
plt.ylabel('log-magnitude')
plt.legend()
# plt.savefig('q4e.pdf')
plt.savefig('q4f.pdf')
# for ii in range(lambda_choice.size):
    